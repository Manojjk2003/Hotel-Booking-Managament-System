from django.contrib import admin
from .models import Contact,Medicines,ProductItems,MyOrders
# Register your models here.
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'price')
    search_fields = ('name', 'description')

class MedicineAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'price')
    search_fields = ('name', 'description')

class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'essage')
    search_fields = ('name', 'email')
    
admin.site.register(Contact)
admin.site.register(Medicines)
admin.site.register(ProductItems)
admin.site.register(MyOrders)